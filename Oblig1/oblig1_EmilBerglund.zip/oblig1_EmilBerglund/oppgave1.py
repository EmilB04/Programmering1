# AUTHOR EMIL BERGLUND#

print("Hello World!")   #Skriver ut strengen "Hello World!" i terminalen.