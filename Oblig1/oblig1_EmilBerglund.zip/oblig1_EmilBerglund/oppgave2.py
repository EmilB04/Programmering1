# AUTHOR EMIL BERGLUND#

fornavn = "Emil"        #Lager en variabel med navnet: "fornavn" og verdien/string: "Emil"
etternavn = "Berglund"  #Gjør det samme som linjen over, kun med annet navn og verdi
alder = 19              #Ny variabel med intiger

print(f"Hei. Jeg heter {fornavn} {etternavn} og er {alder} år gammel.") #Skriver ut en setning ved hjelp av f-string som gjør at man slipper å "klusse" med paranteser og pluss eller komma.